#' Font Size Lookup tables
#' 
#' Lookup tables for font size 
#' 
#' @format A data.frame with column names corresponding to font names
"openxlsxFontSizeLookupTable"

#' @rdname openxlsxFontSizeLookupTable
#' @format NULL
"openxlsxFontSizeLookupTableBold"
