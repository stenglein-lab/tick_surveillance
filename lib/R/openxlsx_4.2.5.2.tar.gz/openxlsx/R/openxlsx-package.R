## usethis namespace: start
#' @importFrom lifecycle deprecate_soft
## usethis namespace: end
